# Website chúc mừng Ngày Phụ nữ Việt Nam 20/10

Trải nghiệm kỹ thuật số single-page: **Pink Floral 50% · Cute Scrapbook 30% · Minimalist Editorial 20%**.

---

## 1. Chạy website

```bash
cd 2010-website
python3 -m http.server 8081 --bind 127.0.0.1
# mở http://127.0.0.1:8081/
```

Không cần build. Chỉ cần một static server (do dùng `fetch`-free, nhưng ES module + CDN nên cần chạy qua http, không mở trực tiếp `file://`).

---

## 2. Cấu trúc

```
2010-website/
├─ index.html            # 5 section + loader, nav, lightbox, to-top
├─ css/style.css         # design tokens, layout, animation, responsive
├─ js/
│  ├─ main.js            # điều phối: reveal, typewriter, lightbox, phong thư 3D
│  └─ petals.js          # cánh hoa rơi bằng Canvas
├─ data/content.js       # TOÀN BỘ nội dung chữ (sửa ở đây, không cần đụng HTML)
├─ assets/images/        # ảnh của bạn
└─ README.md
```

### Section

| # | id | Nội dung |
|---|-----|----------|
| 01 | `#hero` | Opening, tiêu đề, ngày 20 — 10, nút "Khám phá món quà nhỏ" |
| 02 | `#message` | Tấm thiệp lời chúc, hiệu ứng typewriter |
| 03 | `#gallery` | Memory Gallery — Polaroid scrapbook + lightbox |
| 04 | `#letter` | Phong thư 3D mở nắp, lá thư trượt lên |
| 05 | `#final` | Lời chúc cuối, chữ ký "Made with Love" |

---

## 3. Thay ảnh — chỉ cần bỏ file vào thư mục

Tên file **đã cố định**, bạn chỉ cần **ghi đè** bằng ảnh mới cùng tên (giữ nguyên tên file):

| Tên file (trong `assets/images/`) | Vị trí sử dụng | Tỉ lệ gợi ý |
|---|---|---|
| `hero-tulip-bouquet.jfif` | Ảnh chính Section 01 — Hero | dọc / vuông |
| `gallery-bouquet-card.jfif` | Polaroid 1 (bó hoa) | dọc 3:4 |
| `gallery-tulip-coral.jfif` | Polaroid 2 — Tulip | dọc 3:4 |
| `accent-collage-flowers.jfif` | Polaroid 3 — Hoa khô collage | vuông |
| `gallery-ao-dai-poster.jfif` | Polaroid 4 — Áo dài | dọc 3:4 |
| `gallery-tulip-coral.jfif` | Polaroid 5 (dùng lại) | dọc 3:4 |

### Muốn thêm / bớt ảnh gallery?

Mở `data/content.js`, sửa mảng **`gallery.items`**:

```js
gallery: {
  items: [
    { src: 'assets/images/ten-anh-cua-ban.jpg',
      caption: 'Chú thích ngắn',
      note: 'nhãn nhỏ' },   // note có thể để ''
    // thêm bao nhiêu mục cũng được
  ]
}
```

- Ảnh tự được đặt vào khung Polaroid, tự nghiêng góc khác nhau.
- Thêm ảnh mới → chỉ cần copy file vào `assets/images/` và thêm 1 dòng vào mảng.
- **Không cần sửa HTML hay CSS.**

> Định dạng: `.jfif`, `.jpg`, `.png`, `.webp` đều dùng được. Chỉ cần ghi đúng tên trong `src`.

---

## 4. Sửa lời chúc / nội dung chữ

**Mọi câu chữ** nằm trong `data/content.js`:

- `hero` — tiêu đề, tagline, nút
- `message` — tấm thiệp Section 02
- `gallery.items` — danh sách ảnh + chú thích
- `letter` — **nội dung lá thư** (`greeting`, `paragraphs[]`, `close`, `signature`) + nhãn nút (`openLabel` / `closeLabel`)
- `final` — lời chúc cuối, chữ ký
- `music` — đường dẫn nhạc nền (mặc định `null`)

Ví dụ đổi lời chúc trong thư:

```js
letter: {
  greeting: 'Gửi bạn —',
  paragraphs: [
    'Đoạn 1…',
    'Đoạn 2…',
    'Đoạn 3…'
  ],
  close: 'Thân thương nhiều,',
  signature: 'Người đã thiết kế món quà này'
}
```

---

## 5. Nhạc nền (tuỳ chọn)

Nếu bạn có file audio, đặt vào `assets/audio/nhac-nen.mp3` rồi mở `data/content.js` và đổi:

```js
music: 'assets/audio/nhac-nen.mp3'   // thay cho giá trị null mặc định
```

> Nhạc **không tự phát** — chỉ chạy khi người dùng bấm nút loa (đúng chuẩn trình duyệt).

---

## 6. Bảng màu & font

| Token | Mã |
|---|---|
| Ivory | `#FFF9F5` |
| Blush Pink | `#F8E6E9` |
| Dusty Rose | `#DFAAB7` |
| Rose | `#C77D91` |
| Sage Green | `#A8B5A0` |
| Warm Brown | `#735C58` |

Font: **Playfair Display** + **Cormorant Garamond** (heading), **Manrope** (body), **Caveat** (handwriting).

Đổi màu nhanh tại khối `:root` đầu `css/style.css`.

---

## 7. Responsive & accessibility

- Breakpoint: `1024px`, `720px`, `430px`.
- Đã kiểm tra 360 / 390 / 430 / 768 / 1366 / 1920 px — **không tràn ngang**.
- Hỗ trợ `prefers-reduced-motion` (tắt animation khi người dùng yêu cầu).
- Điều hướng bàn phím: `Tab`, `Enter`/`Space` mở thư, `Esc` đóng lightbox, `←/→` chuyển ảnh.

---

## 8. Ghi chú

- Ảnh gốc được giữ nguyên, **không** thay bằng tranh AI.
- Các hoạ tiết hoa/lá trong trang là **SVG vẽ tay bằng code** (nhẹ, sắc nét, đổi màu qua CSS) — bạn có thể thay bằng PNG nếu muốn.
- Nếu thiếu ảnh, khung sẽ hiện nền gradient pastel thay vì ảnh lỗi.

Made with ♥
