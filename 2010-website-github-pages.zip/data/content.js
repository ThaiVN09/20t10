/* ============================================================
   NỘI DUNG WEBSITE 20/10  —  Chỉnh sửa tại đây, không cần đụng code
   ============================================================ */

const CONTENT = {

  /* ---------- SECTION 01 — HERO ---------- */
  hero: {
    eyebrow: "Ngày Phụ nữ Việt Nam",
    titleLine1: "Happy",
    titleLine2: "Women's Day",
    dateBig: "20",
    dateSmall: "10",
    tagline: "Gửi đến những người phụ nữ đã và đang làm nên vẻ đẹp dịu dàng cho cuộc đời này.",
    cta: "Khám phá món quà nhỏ",
    scrollHint: "Cuộn xuống"
  },

  /* ---------- SECTION 02 — A LITTLE MESSAGE ---------- */
  message: {
    stamp: "20 · 10",
    title: "Một lời nhắn nhỏ",
    lines: [
      "Có những điều đẹp đẽ không cần ồn ào —",
      "như nụ cười của mẹ buổi sớm,",
      "như bàn tay chị dịu dàng vỗ về,",
      "như ánh mắt em gái khi vừa hiểu ra điều gì đó."
    ],
    typewriter: "Và hôm nay, xin dành tất cả sự dịu dàng ấy cho bạn.",
    sign: "— Thân thương —"
  },

  /* ---------- SECTION 03 — MEMORY GALLERY ---------- */
  gallery: {
    eyebrow: "Album nhỏ",
    title: "Những mảnh ký ức",
    subtitle: "Nhấn vào từng khung ảnh để xem lớn hơn.",
    // caption hiển thị dưới mỗi Polaroid; ảnh lấy từ assets/images/
    items: [
      {
        src: "assets/images/hero-tulip-bouquet.jfif",
        caption: "Một bó hoa cho người con gái",
        note: "20.10"
      },
      {
        src: "assets/images/gallery-bouquet-card.jfif",
        caption: "Gói ghém cả yêu thương",
        note: "love you"
      },
      {
        src: "assets/images/accent-collage-flowers.jfif",
        caption: "Hoa khô & giấy báo cũ",
        note: "vintage"
      },
      {
        src: "assets/images/gallery-tulip-coral.jfif",
        caption: "Tulip nở đúng ngày",
        note: "bloom"
      },
      {
        src: "assets/images/gallery-ao-dai-poster.jfif",
        caption: "Áo dài — nét duyên Việt Nam",
        note: "Việt Nam"
      }
    ]
  },

  /* ---------- SECTION 04 — SURPRISE LETTER ---------- */
  letter: {
    eyebrow: "Một điều bí mật",
    title: "Có một lá thư dành cho bạn",
    hint: "Nhấn để mở phong thư",
    openLabel: "Mở lá thư",
    closeLabel: "Gấp lại",
    greeting: "Gửi bạn —",
    paragraphs: [
      "Cảm ơn bạn vì đã là chính mình: mạnh mẽ khi cần mạnh mẽ, và dịu dàng theo cách riêng mà không ai bắt chước được.",
      "Mong rằng bạn luôn được yêu thương đúng cách, được trân trọng đúng người, và được phép mệt mỏi khi mọi thứ trở nên quá sức.",
      "Chúc bạn có một ngày 20/10 thật an yên — và những ngày sau đó cũng vậy."
    ],
    close: "Thân thương nhiều,",
    signature: "Người đã thiết kế món quà này"
  },

  /* ---------- SECTION 05 — FINAL WISHES ---------- */
  final: {
    eyebrow: "Lời chúc cuối",
    title: "You Are Special",
    body: "Bạn là một điều đặc biệt. Đừng chỉ nghe điều đó vào ngày 20/10 — hãy tin vào nó mỗi ngày.",
    madeWith: "Made with love",
    signature: "20 · 10"
  },

  /* ---------- NÂNG CẤP: âm nhạc (tuỳ chọn) ----------
     Thêm file nhạc vào assets/audio/ rồi sửa music: "assets/audio/ten-file.mp3"
     Để null nếu không có nhạc. Không bao giờ tự phát khi chưa tương tác.  */
  music: null
};

window.CONTENT = CONTENT;
