/* ==========================================================================
   20 · 10  —  main.js
   Nội dung · Animation · Tương tác
   ========================================================================== */
(function () {
  'use strict';

  const C = window.CONTENT || {};
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const RM = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* =========================================================
     1. ĐỔ NỘI DUNG TỪ content.js
     ========================================================= */
  function injectContent() {
    const set = (id, val) => { const el = document.getElementById(id); if (el && val != null) el.textContent = val; };

    // Hero
    set('heroEyebrow', C.hero?.eyebrow);
    set('heroTitle1', C.hero?.titleLine1);
    set('heroTitle2', C.hero?.titleLine2);
    set('heroDateBig', C.hero?.dateBig);
    set('heroDateSmall', C.hero?.dateSmall);
    set('heroTagline', C.hero?.tagline);
    set('heroCtaLabel', C.hero?.cta);
    set('heroScrollHint', C.hero?.scrollHint);

    // Message
    set('msgStamp', C.message?.stamp);
    set('msgTitle', C.message?.title);
    set('msgSign', C.message?.sign);
    const linesBox = document.getElementById('msgLines');
    if (linesBox && Array.isArray(C.message?.lines)) {
      linesBox.innerHTML = C.message.lines.map(l => `<p>${l}</p>`).join('');
    }

    // Gallery
    set('galEyebrow', C.gallery?.eyebrow);
    set('galTitle', C.gallery?.title);
    set('galSub', C.gallery?.subtitle);

    // Letter
    set('letEyebrow', C.letter?.eyebrow);
    set('letTitle', C.letter?.title);
    set('letGreeting', C.letter?.greeting);
    set('letClose', C.letter?.close);
    set('letSign', C.letter?.signature);
    set('letterBtnLabel', C.letter?.openLabel);
    set('letterHint', C.letter?.hint);
    const bodyBox = document.getElementById('letBody');
    if (bodyBox && Array.isArray(C.letter?.paragraphs)) {
      bodyBox.innerHTML = C.letter.paragraphs.map(p => `<p>${p}</p>`).join('');
    }

    // Final
    set('finEyebrow', C.final?.eyebrow);
    set('finTitle', C.final?.title);
    set('finBody', C.final?.body);
    set('finMade', C.final?.madeWith);
    set('finSig', C.final?.signature);

    document.title = "Happy Vietnamese Women's Day — 20 · 10";
  }

  /* =========================================================
     2. RENDER GALLERY (Polaroid scrapbook)
     ========================================================= */
  function renderGallery() {
    const box = document.getElementById('scrapbook');
    if (!box || !Array.isArray(C.gallery?.items)) return;

    box.innerHTML = C.gallery.items.map((it, i) => `
      <figure class="polaroid" data-anim="photo" data-index="${i}" tabindex="0"
              role="button" aria-label="Xem ảnh: ${it.caption || ''}">
        <span class="polaroid__tape" aria-hidden="true"></span>
        <div class="polaroid__img">
          <img src="${it.src}" alt="${it.caption || ''}" loading="lazy" decoding="async" />
        </div>
        <figcaption class="polaroid__cap">
          <b>${it.caption || ''}</b>
          ${it.note ? `<i>${it.note}</i>` : ''}
        </figcaption>
      </figure>`).join('');
  }

  /* =========================================================
     3. LOADER
     ========================================================= */
  function dismissLoader() {
    const go = () => {
      document.body.classList.remove('is-loading');
      setTimeout(() => runHeroIntro(), RM ? 0 : 260);
    };
    if (document.readyState === 'complete') setTimeout(go, 420);
    else window.addEventListener('load', () => setTimeout(go, 420), { once: true });
    // Safety net
    setTimeout(() => document.body.classList.remove('is-loading'), 4200);
  }

  /* =========================================================
     4. HIỆU ỨNG MỞ ĐẦU HERO (GSAP nếu có, fallback CSS)
     ========================================================= */
  function runHeroIntro() {
    const parts = [
      $('.hero__eyebrow'),
      $('.hero__title .line:nth-child(1)'),
      $('.hero__title .line:nth-child(2)'),
      $('.hero__date'),
      $('.hero__tagline'),
      $('.hero__cta-wrap'),
      $('.hero__photo'),
      $('.hero__scroll')
    ].filter(Boolean);

    const hasGSAP = typeof window.gsap !== 'undefined' && !RM;

    if (hasGSAP) {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
      gsap.set($$('.hero__title .line > span'), { yPercent: 108, opacity: 0 });
      gsap.set(parts, { autoAlpha: 0, y: 30 });

      tl.to('.hero__eyebrow', { autoAlpha: 1, y: 0, duration: .8 })
        .to('.hero__title .line:nth-child(1) > span', { yPercent: 0, opacity: 1, duration: 1.1 }, '-=.5')
        .to('.hero__title .line:nth-child(2) > span', { yPercent: 0, opacity: 1, duration: 1.1 }, '-=.9')
        .to('.hero__date', { autoAlpha: 1, y: 0, duration: .9 }, '-=.75')
        .to('.hero__tagline', { autoAlpha: 1, y: 0, duration: .9 }, '-=.65')
        .to('.hero__cta-wrap', { autoAlpha: 1, y: 0, duration: .8 }, '-=.6')
        .to('.hero__photo', {
          autoAlpha: 1, y: 0, duration: 1.15,
          onStart() { gsap.to('.hero__photo', { rotate: 2.4, duration: 1.2, ease: 'power2.out' }); }
        }, '-=.95')
        .to('.hero__scroll', { autoAlpha: 1, y: 0, duration: .7 }, '-=.6');

      startParallax();
    } else {
      // Fallback: CSS classes
      parts.forEach((el, i) => {
        setTimeout(() => el.classList.add('is-in'), i * 130);
      });
      $$('.hero__title .line').forEach((l, i) => setTimeout(() => l.classList.add('is-in'), 200 + i * 180));
    }
  }

  /* =========================================================
     5. REVEAL KHI CUỘN (IntersectionObserver)
     ========================================================= */
  function setupReveals() {
    const targets = $$('[data-anim], [data-reveal], [data-reveal-lines]');
    if (!targets.length) return;
    if (RM || !('IntersectionObserver' in window)) {
      targets.forEach(t => t.classList.add('is-in'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en, i) => {
        if (!en.isIntersecting) return;
        // stagger nhẹ cho các phần tử cùng section
        const delay = Math.min(i * 90, 320);
        setTimeout(() => en.target.classList.add('is-in'), delay);
        io.unobserve(en.target);
      });
    }, { threshold: 0.16, rootMargin: '0px 0px -8% 0px' });
    targets.forEach(t => io.observe(t));
  }

  /* =========================================================
     6. TYPEWRITER — câu ngắn trong section MESSAGE
     ========================================================= */
  function setupTypewriter() {
    const el = document.getElementById('msgTypewriter');
    const text = C.message?.typewriter;
    if (!el || !text) return;
    el.innerHTML = '<span class="caret"></span>';

    let played = false;
    const play = () => {
      if (played) return; played = true;
      if (RM) { el.textContent = text; return; }
      let i = 0;
      el.innerHTML = '<span class="tw"></span><span class="caret"></span>';
      const tw = el.querySelector('.tw');
      const tick = () => {
        tw.textContent = text.slice(0, ++i);
        if (i < text.length) setTimeout(tick, 34 + Math.random() * 26);
        else setTimeout(() => { const c = el.querySelector('.caret'); if (c) c.remove(); }, 1600);
      };
      setTimeout(tick, 300);
    };

    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver((e) => {
        if (e[0].isIntersecting) { play(); io.disconnect(); }
      }, { threshold: 0.5 });
      io.observe(el);
    } else play();
  }

  /* =========================================================
     7. GALLERY LIGHTBOX
     ========================================================= */
  function setupLightbox() {
    const lb = document.getElementById('lightbox');
    const img = document.getElementById('lbImage');
    const cap = document.getElementById('lbCaption');
    const items = C.gallery?.items || [];
    if (!lb || !img || !items.length) return;

    let current = 0;
    let lastFocus = null;

    const show = (i) => {
      current = (i + items.length) % items.length;
      const it = items[current];
      img.src = it.src;
      img.alt = it.caption || '';
      cap.textContent = it.caption || '';
    };

    const open = (i, trigger) => {
      lastFocus = trigger || document.activeElement;
      show(i);
      lb.hidden = false;
      requestAnimationFrame(() => lb.classList.add('is-visible'));
      document.body.style.overflow = 'hidden';
      document.getElementById('lbClose').focus();
    };

    const close = () => {
      lb.classList.remove('is-visible');
      document.body.style.overflow = '';
      setTimeout(() => { lb.hidden = true; }, 400);
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    };

    const next = () => show(current + 1);
    const prev = () => show(current - 1);

    document.getElementById('scrapbook')?.addEventListener('click', (e) => {
      const card = e.target.closest('.polaroid');
      if (card) open(Number(card.dataset.index), card);
    });
    document.getElementById('scrapbook')?.addEventListener('keydown', (e) => {
      const card = e.target.closest('.polaroid');
      if (card && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); open(Number(card.dataset.index), card); }
    });

    document.getElementById('lbClose').addEventListener('click', close);
    document.getElementById('lbNext').addEventListener('click', next);
    document.getElementById('lbPrev').addEventListener('click', prev);
    lb.addEventListener('click', (e) => { if (e.target === lb) close(); });

    document.addEventListener('keydown', (e) => {
      if (lb.hidden) return;
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowRight') next();
      if (e.key === 'ArrowLeft') prev();
    });

    // Swipe trên mobile
    let x0 = null;
    lb.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', (e) => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 45) (dx < 0 ? next() : prev());
      x0 = null;
    });
  }

  /* =========================================================
     8. PHONG THƯ 3D
     ========================================================= */
  function setupEnvelope() {
    const stage = document.getElementById('envelopeStage');
    const env = document.getElementById('envelope');
    const btn = document.getElementById('letterBtn');
    const label = document.getElementById('letterBtnLabel');
    if (!stage || !env) return;

    let open = false;
    const toggle = () => {
      open = !open;
      stage.classList.toggle('is-open', open);
      env.setAttribute('aria-expanded', String(open));
      if (label) label.textContent = open ? (C.letter?.closeLabel || 'Gấp lại') : (C.letter?.openLabel || 'Mở lá thư');
      if (open) { burstPetals(env); centerLetter(); }
    };

    /* Cuộn nhẹ để lá thư nằm trọn trong khung nhìn */
    function centerLetter() {
      const paper = document.getElementById('letterPaper');
      if (!paper) return;
      // Chờ transition đẩy thư lên rồi mới đo
      setTimeout(() => {
        const r = paper.getBoundingClientRect();
        const vh = window.innerHeight;
        const pad = 24;
        let delta = 0;
        if (r.top < pad) delta = r.top - pad;                 // thư vượt lên trên
        else if (r.bottom > vh - pad) delta = r.bottom - (vh - pad); // thư tràn dưới
        if (Math.abs(delta) > 6) {
          window.scrollBy({ top: delta, behavior: RM ? 'auto' : 'smooth' });
        }
      }, RM ? 60 : 780);
    }

    env.addEventListener('click', toggle);
    env.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });
    btn?.addEventListener('click', toggle);
  }

  /* Bung cánh hoa / trái tim quanh phong thư */
  function burstPetals(host) {
    if (RM) return;
    const rect = host.getBoundingClientRect();
    const layer = document.createElement('div');
    layer.className = 'burst-layer';
    layer.style.cssText = `position:fixed;left:${rect.left + rect.width / 2}px;top:${rect.top + rect.height / 2}px;width:0;height:0;z-index:140;pointer-events:none;`;
    document.body.appendChild(layer);

    for (let i = 0; i < 16; i++) {
      const s = document.createElement('span');
      const isHeart = i % 4 === 0;
      s.textContent = isHeart ? '♥' : '❀';
      s.style.cssText = `
        position:absolute;left:0;top:0;font-size:${13 + Math.random() * 13}px;
        color:${isHeart ? '#DFAAB7' : '#C77D91'};opacity:.95;
        will-change:transform,opacity;`;
      layer.appendChild(s);

      const ang = (Math.PI * 2 * i) / 16 + Math.random() * .5;
      const dist = 90 + Math.random() * 150;
      const dx = Math.cos(ang) * dist;
      const dy = Math.sin(ang) * dist - 40;

      if (typeof window.gsap !== 'undefined') {
        gsap.fromTo(s, { x: 0, y: 0, scale: 0, rotate: 0, opacity: 1 }, {
          x: dx, y: dy, scale: 1 + Math.random(), rotate: Math.random() * 360,
          opacity: 0, duration: 1.5 + Math.random() * .8, ease: 'power2.out'
        });
      } else {
        s.animate(
          [{ transform: 'translate(0,0) scale(0)', opacity: 1 },
           { transform: `translate(${dx}px,${dy}px) scale(1.2) rotate(180deg)`, opacity: 0 }],
          { duration: 1500, easing: 'cubic-bezier(.22,.61,.36,1)' }
        );
      }
    }
    setTimeout(() => layer.remove(), 2600);
  }

  /* =========================================================
     9. NAV · PROGRESS · TO-TOP · PARALLAX · RIPPLE
     ========================================================= */
  function setupChrome() {
    const nav = document.getElementById('nav');
    const toTop = document.getElementById('toTop');
    const bar = document.getElementById('scrollProgress');

    const onScroll = () => {
      const y = window.scrollY;
      nav?.classList.toggle('is-stuck', y > 60);
      toTop?.classList.toggle('is-visible', y > window.innerHeight * 0.7);
      if (bar) {
        const max = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.width = (max > 0 ? (y / max) * 100 : 0) + '%';
      }
      if (typeof window.__parallaxTick === 'function') window.__parallaxTick();
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    toTop?.addEventListener('click', () => {
      document.getElementById('hero')?.scrollIntoView({ behavior: RM ? 'auto' : 'smooth' });
    });

    // Smooth scroll cho nav + CTA
    $$('a[href^="#"]').forEach(a => {
      a.addEventListener('click', (e) => {
        const target = document.querySelector(a.getAttribute('href'));
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: RM ? 'auto' : 'smooth', block: 'start' });
      });
    });

    // Ripple trên nút primary
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.btn--primary');
      if (!btn || RM) return;
      const r = btn.getBoundingClientRect();
      const rip = btn.querySelector('.btn__ripple');
      if (!rip) return;
      const size = Math.max(r.width, r.height);
      rip.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px;transform:scale(0);`;
      void rip.offsetWidth;
      rip.style.animation = 'btnRipple .65s cubic-bezier(.16,1,.3,1) forwards';
    });
  }

  /* Parallax nhẹ cho nền + hero photo */
  function startParallax() {
    if (RM) return;
    const blob1 = $('.blob--1'), blob2 = $('.blob--2'), blob3 = $('.blob--3');
    const photo = $('.hero__photo');
    const vines = $$('.hero__vine');
    let ticking = false;

    window.__parallaxTick = function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const y = window.scrollY;
        if (blob1) blob1.style.transform = `translateY(${y * 0.06}px)`;
        if (blob2) blob2.style.transform = `translateY(${y * -0.04}px)`;
        if (blob3) blob3.style.transform = `translateY(${y * 0.09}px)`;
        if (photo && y < window.innerHeight) {
          photo.style.setProperty('--py', `${y * 0.05}px`);
        }
        vines.forEach((v, i) => {
          const sign = i === 0 ? 1 : -1;
          v.style.marginTop = `${y * 0.035 * sign}px`;
        });
        ticking = false;
      });
    };
  }

  /* =========================================================
     10. NHẠC NỀN (chỉ khi user cung cấp file)
     ========================================================= */
  function setupMusic() {
    const btn = document.getElementById('musicBtn');
    if (!btn || !C.music) return;
    btn.hidden = false;

    const audio = new Audio(C.music);
    audio.loop = true;
    audio.volume = 0;
    let playing = false;

    const fade = (to) => {
      const from = audio.volume, steps = 24; let i = 0;
      const id = setInterval(() => {
        i++; audio.volume = from + (to - from) * (i / steps);
        if (i >= steps) clearInterval(id);
      }, 25);
    };

    // Chỉ phát khi user bấm — không autoplay
    btn.addEventListener('click', () => {
      playing = !playing;
      btn.setAttribute('aria-pressed', String(playing));
      if (playing) { audio.play().then(() => fade(0.42)).catch(() => { playing = false; btn.setAttribute('aria-pressed', 'false'); }); }
      else { fade(0); setTimeout(() => audio.pause(), 700); }
    });
  }

  /* =========================================================
     INIT
     ========================================================= */
  function init() {
    injectContent();
    renderGallery();
    setupReveals();
    setupTypewriter();
    setupLightbox();
    setupEnvelope();
    setupChrome();
    setupMusic();
    dismissLoader();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
