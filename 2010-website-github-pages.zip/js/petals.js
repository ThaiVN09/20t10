/* ==========================================================================
   petals.js — Cánh hoa rơi trên canvas
   Nhẹ, tự nhiên, tự tạm dừng khi tab ẩn, hỗ trợ prefers-reduced-motion
   ========================================================================== */
(function () {
  'use strict';

  const canvas = document.getElementById('petals');
  if (!canvas) return;

  const RM = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (RM) { canvas.style.display = 'none'; return; }

  const ctx = canvas.getContext('2d', { alpha: true });
  let W = 0, H = 0, dpr = 1;
  let petals = [];
  let rafId = null;
  let running = true;

  const COLORS = [
    'rgba(248,230,233,0.95)',
    'rgba(223,170,183,0.92)',
    'rgba(199,125,145,0.85)',
    'rgba(255,255,255,0.9)',
    'rgba(243,220,226,0.95)'
  ];

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    buildPetals();
  }

  function petalCount() {
    const w = window.innerWidth;
    if (w < 480) return 14;
    if (w < 900) return 22;
    return 34;
  }

  function buildPetals() {
    const n = petalCount();
    petals = Array.from({ length: n }, () => spawn(true));
  }

  function spawn(initial) {
    const size = 7 + Math.random() * 12;
    return {
      x: Math.random() * W,
      y: initial ? Math.random() * H : -30 - Math.random() * 80,
      size,
      speedY: 0.25 + Math.random() * 0.65,
      speedX: -0.28 + Math.random() * 0.56,
      sway: Math.random() * Math.PI * 2,
      swaySpeed: 0.006 + Math.random() * 0.014,
      swayAmp: 0.4 + Math.random() * 1.1,
      rot: Math.random() * Math.PI * 2,
      rotSpeed: (-0.5 + Math.random()) * 0.012,
      color: COLORS[(Math.random() * COLORS.length) | 0],
      opacity: 0.35 + Math.random() * 0.5,
      shape: Math.random() < 0.72 ? 'petal' : 'blossom'
    };
  }

  function drawPetal(p) {
    ctx.save();
    ctx.translate(p.x + Math.sin(p.sway) * p.swayAmp * 14, p.y);
    ctx.rotate(p.rot);
    ctx.globalAlpha = p.opacity;
    ctx.fillStyle = p.color;

    const s = p.size;
    if (p.shape === 'petal') {
      // Cánh hoa mềm
      ctx.beginPath();
      ctx.moveTo(0, -s);
      ctx.bezierCurveTo(s * 0.92, -s * 0.55, s * 0.66, s * 0.72, 0, s);
      ctx.bezierCurveTo(-s * 0.66, s * 0.72, -s * 0.92, -s * 0.55, 0, -s);
      ctx.fill();
      // gân nhẹ
      ctx.globalAlpha = p.opacity * 0.32;
      ctx.strokeStyle = 'rgba(199,125,145,0.55)';
      ctx.lineWidth = Math.max(0.5, s * 0.055);
      ctx.beginPath();
      ctx.moveTo(0, -s * 0.82);
      ctx.lineTo(0, s * 0.82);
      ctx.stroke();
    } else {
      // Bông hoa 5 cánh nhỏ
      for (let i = 0; i < 5; i++) {
        ctx.save();
        ctx.rotate((Math.PI * 2 * i) / 5);
        ctx.beginPath();
        ctx.ellipse(0, -s * 0.5, s * 0.34, s * 0.55, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      ctx.globalAlpha = p.opacity * 0.9;
      ctx.fillStyle = 'rgba(199,125,145,0.7)';
      ctx.beginPath();
      ctx.arc(0, 0, s * 0.18, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function frame() {
    if (!running) return;
    ctx.clearRect(0, 0, W, H);

    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      p.y += p.speedY;
      p.x += p.speedX + Math.sin(p.sway) * p.swayAmp * 0.35;
      p.sway += p.swaySpeed;
      p.rot += p.rotSpeed;

      if (p.y > H + 40 || p.x < -80 || p.x > W + 80) {
        petals[i] = spawn(false);
        petals[i].x = Math.random() < 0.5 ? Math.random() * W : (Math.random() < 0.5 ? -20 : W + 20);
      }
      drawPetal(p);
    }
    rafId = requestAnimationFrame(frame);
  }

  function start() { if (!running) { running = true; rafId = requestAnimationFrame(frame); } }
  function stop() { running = false; if (rafId) cancelAnimationFrame(rafId); rafId = null; }

  // Debounce resize
  let rt = null;
  window.addEventListener('resize', () => {
    clearTimeout(rt);
    rt = setTimeout(resize, 180);
  });

  // Tiết kiệm pin: dừng khi tab ẩn
  document.addEventListener('visibilitychange', () => {
    document.hidden ? stop() : start();
  });

  resize();
  rafId = requestAnimationFrame(frame);
})();
